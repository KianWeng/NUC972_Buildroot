#!/bin/sh
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
echo "1" > /proc/sys/net/ipv4/ip_forward
pro='tcp'
NAT_Host='127.0.0.1'
NAT_Port='5022'
Dst_Host='192.0.0.65'
Dst_Port='502'

NAT_Host1='10.0.5.249'
NAT_Port1='8080'
Dst_Host1='192.0.0.65'
Dst_Port1='8080'

NAT_Host2='10.0.5.249'
NAT_Port2='21'
Dst_Host2='192.0.0.65'
Dst_Port2='21'

NAT_Host3='10.0.5.249'
NAT_Port3='122'
Dst_Host3='192.0.0.65'
Dst_Port3='22'

iptables -t nat -A PREROUTING  -m $pro -p $pro --dport $NAT_Port -j DNAT --to-destination $Dst_Host:$Dst_Port
#iptables -t nat -A POSTROUTING -m $pro -p $pro --dport $Dst_Port -d $Dst_Host -j SNAT --to-source $NAT_Host

iptables -t nat -A PREROUTING  -m $pro -p $pro --dport $NAT_Port1 -j DNAT --to-destination $Dst_Host1:$Dst_Port1
#iptables -t nat -A POSTROUTING -m $pro -p $pro --dport $Dst_Port1 -d $Dst_Host1 -j SNAT --to-source $NAT_Host1

iptables -t nat -A PREROUTING  -m $pro -p $pro --dport $NAT_Port2 -j DNAT --to-destination $Dst_Host2:$Dst_Port2
#iptables -t nat -A POSTROUTING -m $pro -p $pro --dport $Dst_Port2 -d $Dst_Host2 -j SNAT --to-source $NAT_Host2

iptables -t nat -A PREROUTING  -m $pro -p $pro --dport $NAT_Port3 -j DNAT --to-destination $Dst_Host3:$Dst_Port3
#iptables -t nat -A POSTROUTING -m $pro -p $pro --dport $Dst_Port3 -d $Dst_Host3 -j SNAT --to-source $NAT_Host3

iptables -t nat -A POSTROUTING -j MASQUERADE

# !/bin/sh

flag=1
result=1

while [ "$flag" -eq 1 ]
do
    sleep 5
    result=`pidof smonitor`
    if [ -z "$result" ]; then
	echo "emp"
        /yy/app/bin/smonitor
    fi
done

ifconfig eth0 10.0.6.112 netmask 255.255.255.0
route delete default
route add default gw 10.0.6.1 dev eth0

#!/bin/sh

ln -fs /sbin/* /bin &
ln -fs /usr/sbin/* /usr/bin &
ln -fs /yy/lib/* /lib/ &

chmod +x /yy/app/bin/smonitor &
/yy/app/port_map.sh &
/yy/app/bin/smonitor &

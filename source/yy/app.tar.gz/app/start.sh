#!/bin/sh

DHCP=0
if [ $DHCP = 1 ]; then
    echo "Start DHCP client."
    #udhcpc 开机自启
    #udhcpc -R -b -p /var/run/udhcpc.eth0.pid -i eth0 
elif [ $DHCP = 0 ]; then
     kill $(cat /var/run/udhcpc.eth0.pid) &&
    echo "Using static IP."
    sleep 1
    /yy/app/script/static_ip.sh
else
    echo "Invalid DHCP parameter."
fi

ln -fs /sbin/* /bin
ln -fs /usr/sbin/* /usr/bin
ln -fs /yy/lib/* /lib/ &&

chmod +x /yy/app/bin/smonitor &&
/yy/app/bin/smonitor &
/yy/app/script/port_map.sh &


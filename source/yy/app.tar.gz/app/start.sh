#!/bin/sh

DHCP=0
if [ $DHCP = 1 ]; then
    echo "Start DHCP client."
    #udhcpc 开机自启
    #udhcpc -R -b -p /var/run/udhcpc.eth0.pid -i eth0 
elif [ $DHCP = 0 ]; then
     kill $(cat /var/run/udhcpc.eth0.pid) &&
    echo "Using static IP."
    sleep 1
    /yy/app/script/static_ip.sh
else
    echo "Invalid DHCP parameter."
fi

ln -fs /sbin/* /bin
ln -fs /usr/sbin/* /usr/bin
ln -fs /yy/lib/* /lib/ &&

if [ ! -d "/media/sd/log/" ];then
     mkdir /media/sd/log/
fi

if [ ! -d "/media/sd/ftp/" ];then
     mkdir /media/sd/ftp/
fi

if [ ! -d "/media/sd/ftp/Alarm/" ];then
     mkdir /media/sd/ftp/Alarm/
fi

if [ ! -d "/media/sd/ftp/Config/" ];then
     mkdir /media/sd/ftp/Config/
fi

if [ ! -d "/media/sd/ftp/Measurement/" ];then
     mkdir /media/sd/ftp/Measurement/
fi

if [ ! -d "/media/sd/ftp/PIC/" ];then
     mkdir /media/sd/ftp/PIC/
fi

if [ ! -d "/media/sd/ftp/logs/" ];then
     mkdir /media/sd/ftp/logs/
fi

if [ ! -d "/media/sd/ftp/upgrade/" ];then
     mkdir /media/sd/ftp/upgrade/
fi

if [ -e "/yy/app/script/arp_bind.sh" ];then
     chmod +x /yy/app/script/arp_bind.sh
     /yy/app/script/arp_bind.sh &
fi

chmod +x /yy/app/bin/smonitor &&
/yy/app/bin/smonitor &
/yy/app/script/port_map.sh &


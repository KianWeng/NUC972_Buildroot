#!/bin/bash

ln -fs /yy/app/lib/* /lib/ &&

cp -r /yy/app/etc/* /etc/

# 邦讯
echo '05c6 9215' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
echo '05c6 9216' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
# 大唐
#echo '12d1 15c1' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
echo '1c9f 9b05' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
#echo '05c6 8022' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动
#echo '1d9f 9c05' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通_1
# 瑞莱普
echo '05c6 9025' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
echo '05c6 f601' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
# 基思瑞
echo '05c6 8080' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通
# 烽火
echo '19d2 0532' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动
echo '1c9e 9b05' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
echo '1c9d 9b05' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
#echo '1c9c 9b05' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通_1
# 中交信达
echo '19d2 0199' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动
echo '1782 0002' > /sys/bus/usb-serial/drivers/option1/new_id  # 联通
echo '05c6 6000' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
echo '161c 9115' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通
echo '161c 9118' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
# 中兴
echo '19d2 1433' > /sys/bus/usb-serial/drivers/option1/new_id  # 移动联通
echo '19d2 1509' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信
echo '19d2 1476' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通
# YY
echo '1e0e 9001' > /sys/bus/usb-serial/drivers/option1/new_id  # 全网通

echo '19f5 9013' > /sys/bus/usb-serial/drivers/option1/new_id  # 联通
echo '19f5 9909' > /sys/bus/usb-serial/drivers/option1/new_id  # 电信


cp -r /yy/app/CASS/BIN/ /home/

chmod +x /home/BIN/*

/home/BIN/port_map.sh &
/home/BIN/CASSFSUService &
/home/BIN/CASSPlugin &
/home/BIN/CASSService &
/home/BIN/CASSUpdateManager &
/home/BIN/SCClient &
